package softuni.exam.models.enums;

public enum VolcanoType {
    CINDER_CONE, STRATOVOLCANO, SHIELD_VOLCANO, LAVA_DOME, CALDERA
}
